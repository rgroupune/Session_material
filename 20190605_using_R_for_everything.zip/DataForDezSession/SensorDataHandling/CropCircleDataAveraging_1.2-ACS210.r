#####Auto Script for ACS 210 Plot Data #####

setwd(choose.dir(caption = "Select folder of raw files"));
files <- list.files(getwd(), pattern = ".CSV");
dname <- vector('list',2);

for (i in seq(along=files)){
  
  print(paste("Processing File",i, "of",length(files),"..."));
  dname[i] <- ifelse(i<10, paste0("data.0",i), paste0("data.",i));
  assign(dname[[i]], read.csv(files[i], header = TRUE));
  tmp.df <- get(dname[[i]]);
  colnames(tmp.df) <- c("PLOT","SAMPLE","SF_1","SF_2","SF_3","NDVI","NIR","RED");
  tmp.df <-na.omit(tmp.df);
  tmp.df.s <- split(tmp.df,tmp.df$PLOT);
  out <- sapply(tmp.df.s, function(m){
    c(Count=length(m$NDVI), NDVI=mean(m$NDVI), NIR=mean(m$NIR), RED=mean(m$RED), FILE=files[i])
  })
  out <-t(out);
  assign(dname[[i]], out);
  Sys.sleep(0.5);
  
};  ## end i loop

print("... All Files Processed");
Sys.sleep(2);
print("Combining input files to generate output...");
Sys.sleep(2);
rm(out,tmp.df,dname,i,tmp.df.s,files)
data.out <- ls()
files <- list.files(getwd(), pattern = ".CSV");
AllDataOut.df <- data.frame()

for (j in seq(along=data.out)) {
  
  AllDataOut.df <- rbind(AllDataOut.df,get(data.out[[j]]))
  
};

print(paste("Writing output .csv file to", paste0(getwd(),"/AllPlotsAveraged.csv")));

###Write all files to one file##
if (file.exists(paste0(getwd(),"/AllPlotsAveraged.csv"))) file.remove(paste0(getwd(),"/AllPlotsAveraged.csv"))
write.csv(AllDataOut.df,file = paste0(getwd(),"/AllPlotsAveraged.csv"))
Sys.sleep(5)
###Final Clean Up##

rm(list = ls())

print("Processing Complete...Auto close in 3secs...")

Sys.sleep(3)
###End Script###