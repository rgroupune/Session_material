####################################################################################
####---R-Support-Group - Using R For Everything---Introductory Scripts---###########
####################################################################################


####Install Packages####

# install.packages("grid")

#### 1.0 - Basic data Types #### 

# Adapted from: https://www.tutorialspoint.com/r/r_data_types.htm

# Create some Examples data objects #

##Vectors##

# Logical Vector
l.v <- c(TRUE, TRUE, FALSE, FALSE, TRUE, FALSE, TRUE, FALSE);
print(l.v);

# Numerical Vector
n.v <- c(1,2,3,4,5,6,7,8);
print(n.v);

# Integer Vector
i.v <- c(1L,2L,3L,4L,5L,6L,7L,8L);
print(n.v);

# Complex Vector
comp.v <- c(1+1i,1+2i,1+3i,1+4i,1+5i,1+6i,1+7i,1+8i); #real and imaginary numbers eg. sqrt(-1)
print(comp.v);

# Character Vector
char.v <- c("this", "is", "a", "great", "way", "to", "waste", "time");
print(char.v);

# Factor Character Vector
f.char.v <- as.factor(char.v);
print(f.char.v); #Once set as a factor, the levels are set, i.e. categorical variables in modelling
print(nlevels(f.char.v)) #If you remove all of a level you may need to recreate the factor to stop the level appearing

# Raw Vector --> List
r.v <- sapply(c("this", "is", "a", "great", "way", "to", "waste", "time"),charToRaw); #Hexadecimal code
r.v #Wait!! This is a list not a vector, let's move on
print(rawToChar(unlist(r.v)));

##Lists##

n.l <- list(c(1,2,3,4,5,6,7,8),8+c(1,2,3,4,5,6,7,8),16+c(1,2,3,4,5,6,7,8));
print(n.l); 

##Matrices##  

n.m <- matrix(c(1:32),nrow = 4, ncol = 8, byrow = TRUE); 
print(n.m); #2D

##Arrays##

n.a <- array(c(n.m,-n.m,n.m),dim=c(4,8,3));
n.a; #3D
plot(n.a);

##Visualisation of array as image##

#runif() creates random numbers, in this example 10000 of them between 0 and 1

r <- matrix(runif(10000, 0, 1), 100, 100) #band 1 - dimension 1 of array
g <- matrix(runif(10000, 0, 1), 100, 100) #band 2 - dimension 2 of array
b <- matrix(runif(10000, 0, 1), 100, 100) #band 3 - dimension 3 of array

col <- rgb(r, g, b)
dim(col) <- dim(r)
rm(r,g,b)
x11(); # opens a plot window
grid::grid.raster(col, interpolate=FALSE);
Sys.sleep(10); 
dev.off();  # closes the plot window

##Data Frames## 

# Unlike a matrix or array, each column can contain different modes of data

d.f <- data.frame("Logical" = l.v,
                          "Numerical" = n.v,
                          "Integer" = i.v,
                          "Complex" = comp.v,
                          "Character" = char.v,
                          "Factor.Char" = f.char.v,
                          stringsAsFactors = FALSE);

str(d.f);
View(d.f);

#########################################################################################
#########################################################################################
#########################################################################################

#### 2.0 - Accessing and manipulating different parts of our R objects ####

# Selecting a column by name
col1 <- d.f$Integer;
print(col1)

# Selecting a column by index
col2 <- d.f[,3];
print(col2);

col1 == col2; # Are they the same?

# Selecting a row by index
row1 <- d.f[3,];
print(row1); # Notice its still a data.frame (differing data mades!)

# Deleting columns by index
d.f2 <- d.f[,-c(3,5)];
print(dim(d.f2)) #

# Deleting Rows by Index
d.f3 <- d.f[-c(3,5),];
print(dim(d.f3))

dim(d.f2) == dim(d.f3) # are they the same?

# Deleting Rows by logic test with a logic column
d.f4 <- d.f[d.f$Logical,]; # Already a logical vector
print(d.f4);

d.f5 <- d.f[!(d.f$Logical),]; # The opposite. ! = does not equal TRUE
print(d.f5);

# Deleting rows by new logic test
d.f6 <- d.f[(d.f$Integer >= 5 | d.f$Character == 'this'),]; # | = OR
print(d.f6);

# Deleting rows using another vector
d.f7 <- d.f[!(d.f$Integer %in% d.f6$Integer),]; # Remove the rows that are present in d.f6 using integer column
print(d.f7);

# Adding new rows to a dataframe

d.f8 <- rbind(d.f7,d.f6);
print(d.f8);

# Replacing rows in a dataframe
d.f9 <- d.f; #Copies an object
d.f9[3,] <- d.f[1,]; # Replaces the third row with the 1st from the original df
print(d.f9); 

# Adding New named column to a dataframe

d.f10 <- d.f;
d.f10$NewOne <- seq(from = 1, to = 64, by = 8);
print(names(d.f10));

# Reordering rows of a dataframe

d.f11 <- d.f10[sort(d.f10$NewOne, decreasing = TRUE),];
print(d.f11)

# Reordering Columns of a dataframe

d.f12 <- d.f[,c(6,3,2,1,5,4)]; #OR
d.f12 <- d.f[,c("Factor.Char","Integer","Numerical","Logical","Character","Complex")];
print(d.f12);

# Renaming Columns

d.f13 <- d.f;
colnames(d.f13) <- c("These", "Are", "New", "Column", "Names", "Honest");
print(d.f13);

# Replacing bulk values

d.f14 <- d.f;
d.f14[d.f14 == 7] <- 9;  # Very handy for replacing NA's or Null data values in DF
print(d.f14);

rm(list = ls()); #Remove everything from environment

########################################################################################
########################################################################################
########################################################################################

#### 3.0 - Higher order functions ####

# Summarising data like Excel Pivot Tables - mean function

dta.in <- iris; #Read in demo data set called iris

str(dta.in)

dta.out <- aggregate(dta.in$Petal.Length,list(dta.in$Species), mean); # Get mean petal length by species
colnames(dta.out) <- c("Species","MeanPetalLength");

# Use our own function - The two standard deviation calculations

dta.out.sd <- aggregate(dta.in$Petal.Length,list(dta.in$Species), sd); # Get sd petal length by species
colnames(dta.out.sd) <- c("Species","SD_PetalLength");

stdev <- function(x){
  sqrt(sum((x - mean(x))^2)/(length(x)))
}; # This calculates the population sd rather than the sample sd

dta.out.stdev <- aggregate(dta.in$Petal.Length,list(dta.in$Species), stdev); # Get sd petal length by species
colnames(dta.out.stdev) <- c("Species","StDev_PetalLength");

dta.out.compare <- cbind(dta.out.sd$SD_PetalLength,dta.out.stdev$StDev_PetalLength);
print(dta.out.compare);

##Very handy user function - if you ever end up with a number stored as a factor##

dta.in$Sepal.Length <- factor(dta.in$Sepal.Length); # Change sepal.length column to factor
str(dta.in$Sepal.Length);
dta.in$Sepal.Length.Wrong <- as.numeric(dta.in$Sepal.Length); #Try and make in numeric again the normal way
as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}; # Create our own function
dta.in$Sepal.Length.correct <- as.numeric.factor(dta.in$Sepal.Length);# Apply our own Function
print(head(dta.in)); # print the 1st few rows

# To apply functions to many objects use the apply() family of functions
# apply(), sapply(), lapply(), mapply(), rapply(), tapply() and vapply()
# Work through the examples shown here: http://www.datasciencemadesimple.com/apply-function-r/

####END Script####


