###Install packages for mapping script#####

install.packages(c("rgdal","raster","automap","cluster","rgeos"));
