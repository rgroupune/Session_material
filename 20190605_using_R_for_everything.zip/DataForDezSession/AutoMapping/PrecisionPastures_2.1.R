#######################################################################################################
######################################################################################################
# Script to automate the zonal mapping of precision pastures data
######################################################################################################
######################################################################################################

# 1.0 - Imports prerequisite data (points and boundary) and has a crack 
# (will source but check the correct format of input files before attempting)
# 2.0 - Will take many sources point data (RAAP paddock demo)

####Load Libraries####

#install.packages("rgdal","raster","automap","cluster");

library(rgdal);
library(raster);
library(automap);
library(cluster);
library(rgeos);


####Import Data####

setwd(choose.dir(caption = "Select the folder containing your raw data files and shapefile", default = "C:/R/2018-05-29_PrecisionPastures/")); #asks for location of working directory

files.shp <- list.files(getwd(), pattern = ".shp", ignore.case = TRUE, recursive = FALSE); #get a list of the .shp files (boundary file only with wgs coordinate system)

B.File <- gsub(".shp", "",files.shp[1]); #remove the .shp from the shapefile name
boundary <- readOGR(getwd(),B.File); #import the boundary shapefile
#plot(boundary, col = rainbow(100)[sample(1:100,1)]); #plot the boundary shapefile

files.csv <- list.files(getwd(), pattern = ".csv", ignore.case = TRUE, recursive = FALSE); #get a list of the .csv files

dname <- vector('list');
krig.nams <- data.frame(File = '', Layer = '', Name = '', KrigeName = '');
krig.nams <- krig.nams[-1,];


####Set the coordinate system to use####

####Set the projection and project the data####
UCRS.new <- CRS("+proj=utm +zone=56 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs"); #projected coordinate system for eastern NSW/Qld
print("Using projected coordinate system: WGS 1984 UTM Zone 56S")

boundary <- spTransform(boundary, UCRS.new); #transform boundary

####Ask for the preferred gris size to interpolate to####

con <- if (interactive()) stdin() else file('stdin')
message('What sized grid would you like to use (recommended = 5)??  ')
grd.size <- scan(file=con, sep=',', nlines=1, quiet=TRUE)

####Create grid####

origin <- SpatialPoints(cbind(7,40),UCRS.new);
grd <- raster();
e <- extent(boundary@bbox[1,1],boundary@bbox[1,2],boundary@bbox[2,1],boundary@bbox[2,2]);
extent(grd) <- e;
res(grd) <- c(grd.size,grd.size);
projection(grd) <- UCRS.new;
grd[] <- 0
####Convert raster grid file to Points####
grd.points <- rasterToPoints(grd, fun=function(x) {x == 0}, dissolve=FALSE);
grd.points <- SpatialPoints(grd.points,UCRS.new)
grd.points <- intersect(grd.points,boundary)
x11()
plot(boundary, main = "Paddock Boundary with Grid")
plot(grd.points, pch = 16, cex = 0.4, col = 'blue', add = TRUE)
Sys.sleep(5)
dev.off()
#writeOGR(grd.points,paste0(getwd(),"\\GridPoints"),paste0("Point-GRID_",grd.size,"x",grd.size,"m"), driver="ESRI Shapefile");


for (i in seq_along(files.csv)){
  #i = 2
  #print(paste("layer ",i))
  dname <- c(dname,paste("data",i, sep = "."))
  assign(dname[[i]], read.csv(files.csv[i], header = TRUE))
  dta.in <- get(dname[[i]]);
  num.layers <- length(colnames(dta.in))-3
  if (num.layers != 1) num.layers <- seq(from = 4, to = length(colnames(dta.in)),by = 1)
  suppressWarnings(if (num.layers == 1) num.layers <- 4)
  coords <- SpatialPoints(data.frame(X = dta.in$X,Y = dta.in$Y, Obs = dta.in[num.layers]),CRS("+proj=utm +zone=56 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs")); #create a spatial object from the point data
  #x11()
  plot(boundary, col = rainbow(100)[sample(1:100,1)]); #plot the boundary shapefile
  plot(coords, col = "black", pch = 16, cex = 0.5, add = TRUE) #add the points to the plot
  title(files.csv[i])
  #Sys.sleep(5)
  #dev.off()
  d.UTM <- spTransform(coords, UCRS.new); #transform points
  d.UTM <- SpatialPointsDataFrame(coords = d.UTM,data = dta.in)
  d.UTM@coords <- d.UTM@coords[, 1:2]
  ####Perform Interpolation on all layers####
  lay.nams <- colnames(dta.in[num.layers])
  krig.form <- vector()
  krig.nam <- vector()
  oi <- data.frame(File = '', Layer = '', Name = '', KrigeName = '')
  oi <- oi[-1,]
  for (j in seq_along(lay.nams)){
    #j = 1
    message(paste("File", i, "Layer", j))
    krig.form[j] <- paste0(lay.nams[j]," ~ 1")
    krig.nam[j] <- paste0(dname[i],"_KrigeOut_0",j)
    KrigeOut <- autoKrige(as.formula(krig.form[j]), input_data = d.UTM, new_data = grd.points, model = c("Sph", "Exp", "Gau", "Ste"), nmin = 10, nmax = 100, maxdist = 100, block = c(10,10), verbose=TRUE)
    plot(KrigeOut)
    assign(krig.nam[j],KrigeOut$krige_output$var1.pred)
    oi <- suppressWarnings(rbind(oi,data.frame(File = files.csv[i], Layer = lay.nams[j], Name = dname[[i]], KrigeName = krig.nam[j])))
    #grd.points@data <- data.frame('data' = krig.nam[j])
  } #END j Loop
  suppressWarnings(krig.nams <- rbind(krig.nams,oi))
} # END i Loop


####Create File to cluster####
GridData <- data.frame('ID' = 1:length(grd.points@data[,1]))

for (k in seq_along(krig.nams$KrigeName)){
  #k = 1
  GridData[k] <- get(as.character(krig.nams$KrigeName[[k]]))
} #END k loop

colnames(GridData) <- krig.nams$Layer

####Cluster the Interpolated map####

data.ready <- data.frame('data' = GridData) #remove ID, x and y columns
data.ready <- scale(data.ready) #Standardise variables

##Partitioning

# Determine number of clusters
wss <- (nrow(data.ready)-1)*sum(apply(data.ready,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(data.ready, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

# Fit Quadratic Plateau Modelling
Mean <- function(x, alpha, beta, gamma) { 
  ifelse(x < -beta/(2 * gamma), alpha + beta*x + gamma*x*x, 
         alpha - beta^2/(4 * gamma)) 
} 

sp.in <- 1:15
fm <- nls(wss ~ Mean(sp.in, alpha, beta, gamma), start = list(alpha = 0.45, beta = 0.05, gamma = -0.0025));
fm;

x11()
plot(wss ~ sp.in);
lines(fitted(fm) ~ sp.in);
with(as.list(coef(fm)), abline(v = -beta/(2 * gamma)));
Sys.sleep(5)
dev.off()
thresh <- with(as.list(coef(fm)), (v = -beta/(2 * gamma)));
thresh <- floor(thresh)
message(paste("Number of Zones Recommended =",thresh));
message("Would you like to overwrite? Yes/No")
overwrite <- scan(file=con, sep=',', nlines=1, what = 'character', quiet=TRUE)
brat <- function(){
  message("How many zones?")
  thresh <- scan(file=con, sep=',', nlines=1, quiet=TRUE)
  return(thresh)
}

if (overwrite == 'Yes' | overwrite == 'Y'| overwrite == 'yes' | overwrite == 'y') thresh <- brat() 

# K-Means Cluster Analysis
fit <- kmeans(data.ready, thresh) # cluster solution

# get cluster means 
oi <- aggregate(data.ready,by=list(fit$cluster),FUN=mean)
oi1 <- oi[-1]
oi.orig <- (apply(oi1, 1, function(r)r * attr(data.ready,'scaled:scale') + attr(data.ready, 'scaled:center')))
oi.orig <- data.frame(oi.orig)
colnames(oi.orig) <- paste0("Cluster_",1:thresh)
rm(oi1)

# append cluster assignment

data.orig = (apply(data.ready, 1, function(r)r*attr(data.ready,'scaled:scale') + attr(data.ready, 'scaled:center')))
#data.orig <- data.frame(X = data.in$X,Y = data.in$Y,data.orig, Cluster = fit$cluster)
grd.points2 <- data.frame(cbind(grd.points@coords,fit$cluster))
grd.points2 <- grd.points2[-3]
names(grd.points2) <- c("X","Y","Cluster")
grd.points2 <- cbind(grd.points2,GridData)
grd.points3 <- SpatialPoints(coords = data.frame(X = grd.points2[1], Y = grd.points2[2]),CRS("+proj=utm +zone=56 +south +ellps=WGS84 +datum=WGS84 +units=m +no_defs"))
grd.points4 <- SpatialPointsDataFrame(coords = grd.points3, data = grd.points2)

writeOGR(grd.points4,paste0(getwd(),"\\SHPsOut"),paste0("Point-GRID_",grd.size,"x",grd.size,"m_KrigedClustered"), driver="ESRI Shapefile");

dir.create(paste0(getwd(),"\\CSVsOut\\"))

print(oi.orig)
write.csv(oi.orig, paste0(getwd(),"\\CSVsOut\\ClusterMeans.csv"))
write.csv(grd.points2, paste0(getwd(),"\\CSVsOut\\AllDataInterpolated.csv"))

####Plot it Up as Rasters####

for (l in 4:length(grd.points2)) {
  print(l)
  rast <- raster()
  extent(rast) <- extent(grd.points4) # this might be unnecessary
  ncol(rast) <- 20 # this is one way of assigning cell size / resolution
  nrow(rast) <- 50
  rast@crs <- UCRS.new
  rast2 <- rasterize(grd.points4, rast, grd.points4[[l]], fun=mean)
  x11()
  plot(rast2,col = rainbow(100), main = paste(names(grd.points2[l])))
  Sys.sleep(5)
  dev.off()
  plot(rast2,col = rainbow(100), main = paste(names(grd.points2[l])))
}

rast <- raster()
extent(rast) <- extent(grd.points4) # this might be unnecessary
ncol(rast) <- 20 # this is one way of assigning cell size / resolution
nrow(rast) <- 50
rast@crs <- UCRS.new
rast2 <- rasterize(grd.points4, rast, grd.points4[[3]], fun=mean)
x11()
plot(rast2,col = rainbow(100), main = paste(names(grd.points2[3])))
Sys.sleep(5)
dev.off()
plot(rast2,col = rainbow(100), main = paste(names(grd.points2[3])))


print("Processing Complete!")

Sys.sleep(5)




